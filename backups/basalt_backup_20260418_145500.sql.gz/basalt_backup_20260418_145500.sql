PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE roles (
	id INTEGER NOT NULL, 
	code VARCHAR(50) NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	permissions JSON, 
	max_clearance INTEGER NOT NULL, 
	PRIMARY KEY (id)
);
INSERT INTO roles VALUES(1,'sysadmin','系统管理员','["policy:manage", "user:manage", "role:manage"]',3);
INSERT INTO roles VALUES(2,'auditadmin','审计管理员','["audit:view", "audit:export"]',2);
INSERT INTO roles VALUES(3,'ordinary','普通用户','[]',1);
CREATE TABLE employees (
	id INTEGER NOT NULL, 
	name VARCHAR(50) NOT NULL, 
	department VARCHAR(50), 
	encrypted_phone VARCHAR(255) NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE system_configs (
	id INTEGER NOT NULL, 
	"key" VARCHAR(100) NOT NULL, 
	value VARCHAR(500) NOT NULL, 
	description VARCHAR(500), 
	PRIMARY KEY (id)
);
INSERT INTO system_configs VALUES(1,'LOGIN_MAX_FAILURES','5','最大容错值');
INSERT INTO system_configs VALUES(2,'LOGIN_LOCKOUT_MINUTES','30','惩罚隔离阈值');
INSERT INTO system_configs VALUES(3,'PWD_COMPLEXITY_ENFORCE','true','强制鉴别口令难度');
INSERT INTO system_configs VALUES(4,'SESSION_TIMEOUT_MINS','15','会话超时自动失效');
INSERT INTO system_configs VALUES(5,'PWD_MAX_AGE_DAYS','90','口令最长使用期限(天)');
INSERT INTO system_configs VALUES(6,'PWD_HISTORY_COUNT','5','密码历史记录数（禁止复用）');
INSERT INTO system_configs VALUES(7,'INACTIVE_DAYS_LIMIT','180','非活跃账号自动停用天数');
CREATE TABLE users (
	id INTEGER NOT NULL, 
	username VARCHAR(50) NOT NULL, 
	hashed_password VARCHAR(255) NOT NULL, 
	role_code VARCHAR(50) NOT NULL, 
	totp_secret VARCHAR(32), 
	is_active BOOLEAN, 
	is_locked BOOLEAN, 
	lock_expires_at DATETIME, 
	password_updated_at DATETIME, 
	last_login_at DATETIME, 
	encrypted_phone VARCHAR(255), 
	PRIMARY KEY (id)
);
INSERT INTO users VALUES(1,'sysadmin','$2b$12$.liSJ3mNAD9NSSeMB07Ss.G3MiVTQX51SFOKRr1pgZ58bCnWHz81a','sysadmin',NULL,1,0,NULL,'2026-04-18 06:54:59.508796','2026-04-18 06:54:59.950577',NULL);
INSERT INTO users VALUES(2,'auditadmin','$2b$12$DmGXovvywmkUB8A7VIFF0.z5sdMPb60Kg3/O7cALpy1qjtBezOAgC','auditadmin',NULL,1,0,NULL,NULL,NULL,NULL);
CREATE TABLE password_history (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	hashed_password VARCHAR(255) NOT NULL, 
	created_at DATETIME, 
	PRIMARY KEY (id)
);
INSERT INTO password_history VALUES(1,1,'$2b$12$DmGXovvywmkUB8A7VIFF0.z5sdMPb60Kg3/O7cALpy1qjtBezOAgC','2026-04-18 06:54:59.234959');
CREATE TABLE login_attempts (
	id INTEGER NOT NULL, 
	ip_address VARCHAR(45) NOT NULL, 
	username VARCHAR(50), 
	success BOOLEAN, 
	attempt_time DATETIME, 
	PRIMARY KEY (id)
);
INSERT INTO login_attempts VALUES(1,'127.0.0.1','sysadmin',1,'2026-04-18 06:54:59.951316');
CREATE TABLE ip_whitelists (
	id INTEGER NOT NULL, 
	ip_network VARCHAR(45) NOT NULL, 
	description VARCHAR(255), 
	created_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE TABLE audit_logs (
	id INTEGER NOT NULL, 
	timestamp DATETIME, 
	user_id VARCHAR(50) NOT NULL, 
	ip_address VARCHAR(45) NOT NULL, 
	action VARCHAR(100) NOT NULL, 
	resource VARCHAR(255) NOT NULL, 
	status VARCHAR(20) NOT NULL, 
	details TEXT, 
	PRIMARY KEY (id)
);
INSERT INTO audit_logs VALUES(1,'2026-04-18 06:54:59.513614','sysadmin','127.0.0.1','RESET_EXPIRED_PASSWORD','http://localhost:8000/api/v1/auth/reset-expired-password','SUCCESS','');
INSERT INTO audit_logs VALUES(2,'2026-04-18 06:54:59.957975','sysadmin','127.0.0.1','LOGIN_SUCCESS','http://localhost:8000/api/v1/auth/login','SUCCESS','{"ip": "127.0.0.1"}');
CREATE TRIGGER audit_logs_no_update
                    BEFORE UPDATE ON audit_logs
                    BEGIN
                        SELECT RAISE(ABORT, '等保安全策略：审计日志禁止修改');
                    END;
CREATE TRIGGER audit_logs_no_delete
                    BEFORE DELETE ON audit_logs
                    BEGIN
                        SELECT RAISE(ABORT, '等保安全策略：审计日志禁止删除');
                    END;
CREATE INDEX ix_roles_id ON roles (id);
CREATE UNIQUE INDEX ix_roles_code ON roles (code);
CREATE INDEX ix_employees_id ON employees (id);
CREATE INDEX ix_system_configs_id ON system_configs (id);
CREATE UNIQUE INDEX ix_system_configs_key ON system_configs ("key");
CREATE UNIQUE INDEX ix_users_username ON users (username);
CREATE INDEX ix_users_id ON users (id);
CREATE INDEX ix_password_history_user_id ON password_history (user_id);
CREATE INDEX ix_password_history_id ON password_history (id);
CREATE INDEX ix_login_attempts_username ON login_attempts (username);
CREATE INDEX ix_login_attempts_ip_address ON login_attempts (ip_address);
CREATE INDEX ix_login_attempts_id ON login_attempts (id);
CREATE INDEX ix_ip_whitelists_id ON ip_whitelists (id);
CREATE INDEX ix_audit_logs_id ON audit_logs (id);
CREATE INDEX ix_audit_logs_user_id ON audit_logs (user_id);
CREATE INDEX ix_audit_logs_timestamp ON audit_logs (timestamp);
COMMIT;
